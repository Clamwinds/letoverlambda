/* ------------------------------ */
/*  Global variables declaration  */
/* ------------------------------ */
var selected_data = [];


$(document).foundation();

/* -------------------- */
/* addBuilding function */
/* -------------------- */
function addBuilding() {

	var newBldgNum = parseInt($(".buildingSection").length) + 1;

	var bldgSectionHTML = $(".buildingSectionSample").html();

	var contentHTML = '<div class="buildingSection" id="' + 'bldg-' + newBldgNum + '">' + bldgSectionHTML + '</div>';

	$("#buildingSectionGroup").append(contentHTML);
    var $section = $("#buildingSectionGroup").find("#bldg-" + newBldgNum);	

    // overwrite new building number after appending
    $section.find(".bldgName").text("Building " + newBldgNum);

    // overwrite radio button name after appending 
    $section.find("input[name^=sqftOpt]").attr("name", "sqftOpt-bldg-" + newBldgNum); 

    // overwrite radio button name after appending 
    $section.find("input[name^=sqftInput]").attr("name", "sqftInput-bldg-" + newBldgNum); 

}


/* -------------------- */
/* "Go" button function */
/* -------------------- */
function goBtn() {

    var totalSqft = 0;
    var numDaysDescr = "";

	$(".buildingSection").each(function() {

		var sectionId = $(this).attr("id");
        var bldgDetails = {};
		bldgDetails.bldgName = $(this).find(".bldgName").text();
        bldgDetails.zipCode = $(this).find(".zipCodeInput").val();
		bldgDetails.numOfDays = $(this).find("input[name=sqftOpt-" + sectionId + "]:checked").val();
		bldgDetails.sqft = $(this).find("input[name=sqftOpt-" + sectionId + "]:checked").closest(".sqftOptRow").find(".sqftInput").val();


        numDaysDescr = $(this).find("input[name=sqftOpt-" + sectionId + "]:checked").parent().find("label").text();
        totalSqft = totalSqft + Number(bldgDetails.sqft);

		console.log("sectionId:" + sectionId + " bldgname:" + bldgDetails.bldgName + ", numOfDays:" + bldgDetails.numOfDays + ", numDaysDescr:" + numDaysDescr + ", bldgDetails.sqft:" + bldgDetails.sqft);

		selected_data.push(bldgDetails);

		//Display building and options selected

		var bldgSelectionHTML = '<div class="row bldgNumRow">' + 
                        		    bldgDetails.bldgName + 
                        		'</div>' + 
	                        	'<div class="row detailsRow">' + 
		                            '<div class="small-5 medium-3 column">' +
		                                numDaysDescr + 
		                            '</div>' +     
		                            '<div class="small-3 medium-2 column">' +
		                                bldgDetails.sqft  + ' SqFt' +
		                            '</div>' +    
		                            '<div class="small-4 medium-1 column end">' + 
		                                '<a href="#" class="btn btnSmall">Edit</a>' + 
		                            '</div>' +     
		                        '</div>';


		$(".confirmBldgOptionsSeletion").append(bldgSelectionHTML);

	});

    var totalHTML = '<hr class="partialHR"/>' +
                    '<div class="row totalRow">' + 
                        '<div class="small-5 medium-3 column">' +
                            'Total' + 
                        '</div>' +     
                        '<div class="small-3 medium-2 column end">' +
                            totalSqft  + ' SqFt' +
                        '</div>' +                          
                    '</div>' +
                    '<hr/>';     

    $(".confirmBldgOptionsSeletion").append(totalHTML);                    


	console.log("selected_data: " + selected_data);

	$("#content1").hide();
	$("#content2").show();

}


/* -------------------- */
/* "Go" button function */
/* -------------------- */
function sendBtn() {


    // Validate email both email addresses are the same
    var emailAddrVal1 = $("#content2 #emailAddrInput1").val();
    var emailAddrVal2 = $("#content2 #emailAddrInput2").val();

    if ($.trim(emailAddrVal1) !== $.trim(emailAddrVal2) ) {

        $("#emailErrorMsg").show();
        return false;
    }

    // Send data to backend
    var dataForBackend = { emailAddr: emailAddrVal1, buildings: selected_data };

    $.ajax({
            type: "POST",
            url: "senddata_api",
            data: JSON.stringify(dataForBackend),
            cache: false,
            success: function(data){
                    alert(data); //Returning value
                    //location.href = "pricing_submit.html";
            }
    });

    console.log("JSON.stringify(dataForBackend):" + JSON.stringify(dataForBackend));

    // Display confirmation inside a Foundation modal window 
    $('#confirmationWindow').foundation('open');
}	



/* ------------------------ */
/*  Display Error function  */
/* ------------------------ */
function displayError(type) {

    var errorHTML = "";

    switch (type) {
        case 'zipcode':
            errorHTML = "<div>Ah, we are sorry. We're not available in your zipcode yet. It's in our roadmap for sure.</div>" + 
                        "Would you like to receive email notification when we are?" + 
                        "<div class='emailAddrLine row'>" +    
                            "<div class='small-12 medium-4 column'>" + 
                                "<span class='emailAddrLabel'>Email Address</span>" + 
                            "</div>" + 
                            "<div class='small-12 medium-8 column'>" +
                                "<input type='text' placeholder='' class='emailAddrInput' id='emailAddrInput2'>" + 
                            "</div>" + 
                        "</div>" + 
                        "<div class='buttonWrapper'>" + 
                            "<a href='javascript:void(0)' class='btn sendBtn' onclick='reqEmailNotifBtn();''>Send</a>" + 
                            "<a href='#' data-close class='btn cancelBtn' id='cancelInsideModalBtn'>Cancel</a>" + 
                        "</div>";    
            break;
    }

    $('#errorWindow').find('#errorMsg').html(errorHTML);
    $('#errorWindow').foundation('open');

}


/* ---------------------- */
/*  "ZipCode" validation  */
/* ---------------------- */
$(".zipCodeInput").blur(function() {

    var dataForBackend = { zipcode: $(this).val() };

    // validate zipcode
    $.ajax({
        type: "POST",
        url: "zipcode_api",
        data: JSON.stringify(dataForBackend),
        cache: false,
        success: function(data){

            // If error
            displayError('zipcode');
        }
    });

    displayError('zipcode');


});


/*
$(document).ready(function() {

    $("#goBtn").on('click', function () { 

        var zipCodeInput = $(".zipCodeInput").val();
        var sqftInput = $(".sqftInput").val();
        var sqftOpt = $(".sqftOpt").val();
        var jsonData = {zipCode: zipCodeInput, sqft: sqftInput, frequency: sqftOpt, buildingNum: "1"};

        alert(JSON.stringify(jsonData) + "test:" +jsonData.zipCode);



        $.ajax({
            type: "POST",
            url: "api/createLead",
            data: jsonData,
            cache: false,
            success: function(data){
                    alert(data); //Returning value
                    //location.href = "pricing_submit.html";
            }
            });


        });


    }); //Document ready
*/
